package com.mahmoud.slips

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Environment
import android.provider.MediaStore
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Slip(
    val id: Long, val serial: String, val amount: Double, val method: Int,
    val date: String, val time: String, val cashier: String
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "slips.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL(
            "CREATE TABLE slips(id INTEGER PRIMARY KEY AUTOINCREMENT, serial TEXT, amount REAL, " +
                "method INTEGER, date TEXT, time TEXT, cashier TEXT, UNIQUE(serial, date))"
        )
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    /** يرجع false إذا كان الوصل (الرقم + التاريخ) مسجلاً من قبل */
    fun insert(s: Slip): Boolean {
        val cv = ContentValues().apply {
            put("serial", s.serial); put("amount", s.amount); put("method", s.method)
            put("date", s.date); put("time", s.time); put("cashier", s.cashier)
        }
        return writableDatabase.insertWithOnConflict("slips", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun all(): List<Slip> {
        val out = ArrayList<Slip>()
        readableDatabase.rawQuery(
            "SELECT id, serial, amount, method, date, time, cashier FROM slips ORDER BY id DESC", null
        ).use { c ->
            while (c.moveToNext()) out.add(
                Slip(c.getLong(0), c.getString(1), c.getDouble(2), c.getInt(3),
                    c.getString(4) ?: "", c.getString(5) ?: "", c.getString(6) ?: "")
            )
        }
        return out
    }

    fun delete(id: Long) { writableDatabase.delete("slips", "id=?", arrayOf(id.toString())) }
    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM slips", null).use { it.moveToFirst(); it.getInt(0) }
}

private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
private val COLS = arrayOf("A", "B", "C", "D", "E", "F", "G", "H")

fun buildXlsx(out: OutputStream, slips: List<Slip>) {
    val sb = StringBuilder()
    sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews><sheetData>""")
    val head = listOf("التاريخ", "الوقت", "الكاشير", "رقم الوصل") + METHODS.toList()
    sb.append("<row r=\"1\">")
    head.forEachIndexed { i, h -> sb.append("<c r=\"${COLS[i]}1\" t=\"inlineStr\"><is><t>${esc(h)}</t></is></c>") }
    sb.append("</row>")
    slips.sortedWith(compareBy({ it.date.split("/").reversed().joinToString("") }, { it.time })).forEachIndexed { idx, s ->
        val r = idx + 2
        sb.append("<row r=\"$r\">")
        sb.append("<c r=\"A$r\" t=\"inlineStr\"><is><t>${esc(s.date)}</t></is></c>")
        sb.append("<c r=\"B$r\" t=\"inlineStr\"><is><t>${esc(s.time)}</t></is></c>")
        sb.append("<c r=\"C$r\" t=\"inlineStr\"><is><t>${esc(s.cashier)}</t></is></c>")
        sb.append("<c r=\"D$r\"><v>${s.serial}</v></c>")
        sb.append("<c r=\"${COLS[4 + s.method]}$r\"><v>${s.amount}</v></c>")
        sb.append("</row>")
    }
    sb.append("</sheetData></worksheet>")
    ZipOutputStream(out).use { z ->
        fun put(name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        put("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
        put("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
        put("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="الوصولات" sheetId="1" r:id="rId1"/></sheets></workbook>""")
        put("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
        put("xl/worksheets/sheet1.xml", sb.toString())
    }
}

/** يحفظ الملف في مجلد Downloads ويرجع اسمه */
fun exportXlsx(ctx: Context, slips: List<Slip>): String {
    val name = "slips_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".xlsx"
    val cv = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, name)
        put(MediaStore.Downloads.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { buildXlsx(it, slips) }
    return name
}
