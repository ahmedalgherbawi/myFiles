package com.mahmoud.slips

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

// ترتيب الأعمدة من اليمين إلى اليسار كما على الوصل
val METHODS = arrayOf("بنك فلسطين", "بطاقة", "QR PalPay", "جوال باي")

const val GW = 0.90f          // عرض الإطار الأخضر نسبةً لعرض الصورة
const val GH = 0.78f          // ارتفاع الإطار
const val BLUE_FROM = 0.45f   // نبحث عن الختم الأزرق في ما دون هذه النسبة من ارتفاع الوصل
const val BLUE_MIN = 60       // أقل عدد نقاط زرقاء لاعتبار الختم موجوداً

data class Parsed(
    val serial: String?, val amount: Double?, val date: String?,
    val time: String?, val method: Int, val blue: Int
)

object Digits {
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(
            when (c) {
                in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
                in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
                else -> c
            }
        )
        return sb.toString()
    }
}

class SlipAnalyzer(private val onParsed: (Parsed) -> Unit) : ImageAnalysis.Analyzer {
    private val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var last = 0L
    private var busy = false

    override fun analyze(proxy: ImageProxy) {
        val now = SystemClock.elapsedRealtime()
        if (busy || now - last < 300) { proxy.close(); return }
        last = now
        val bmp = try {
            val raw = proxy.toBitmap()
            val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
        } finally {
            proxy.close()
        }
        val w = bmp.width
        val h = bmp.height
        val cw = (w * GW).toInt()
        val ch = (h * GH).toInt()
        val crop = Bitmap.createBitmap(bmp, (w - cw) / 2, (h - ch) / 2, cw, ch)
        val (blue, cx) = blueStats(crop)
        busy = true
        rec.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { onParsed(parse(it, ch, blue, cx)) }
            .addOnCompleteListener { busy = false }
    }

    private fun blueStats(b: Bitmap): Pair<Int, Float> {
        val w = b.width
        val h = b.height
        val step = 4
        var n = 0
        var sx = 0L
        var y = (h * BLUE_FROM).toInt()
        while (y < h) {
            var x = 0
            while (x < w) {
                val p = b.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
                if (bl > 110 && bl - r > 50 && bl - g > 25) { n++; sx += x }
                x += step
            }
            y += step
        }
        return Pair(n, if (n > 0) sx.toFloat() / n / w else 0.5f)
    }

    private fun parse(t: Text, ch: Int, blue: Int, cx: Float): Parsed {
        var date: String? = null
        var time: String? = null
        var amount: Double? = null
        val serials = linkedSetOf<String>()
        val dateRe = Regex("""(\d{2})/(\d{2})/(\d{4})""")
        val timeRe = Regex("""(?<!\d)(\d{2}):(\d{2})(?!\d)""")
        val amtRe = Regex("""(?<![\d.,])(\d{1,6})[.,](\d{2})(?!\d)""")
        val serRe = Regex("""\d{3,6}""")
        for (bl in t.textBlocks) for (ln in bl.lines) {
            val s = Digits.norm(ln.text)
            if (date == null) dateRe.find(s)?.let { date = it.value }
            if (time == null) timeRe.find(s)?.let { time = it.value }
            if (amount == null) amtRe.find(s)?.let { amount = "${it.groupValues[1]}.${it.groupValues[2]}".toDouble() }
            for (el in ln.elements) {
                val e = Digits.norm(el.text).replace("/", "").trim()
                val y = el.boundingBox?.centerY() ?: 0
                if (serRe.matches(e) && y < ch * 0.62) serials.add(e)
            }
        }
        val year = date?.takeLast(4)
        serials.remove(year)
        val serial = if (serials.size == 1) serials.first() else null
        val method = if (blue >= BLUE_MIN) ((1f - cx) * 4).toInt().coerceIn(0, 3) else -1
        return Parsed(serial, amount, date, time, method, blue)
    }
}
