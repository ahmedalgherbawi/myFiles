package com.mahmoud.slips

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.SystemClock
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.Executors

class GuideView(c: Context) : View(c) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 4f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; textSize = 30f; textAlign = Paint.Align.CENTER }
    override fun onDraw(c: Canvas) {
        val vw = width.toFloat(); val vh = height.toFloat()
        val cw: Float; val chh: Float
        if (vw / vh > 0.75f) { chh = vh; cw = vh * 0.75f } else { cw = vw; chh = vw / 0.75f }
        val ox = (vw - cw) / 2; val oy = (vh - chh) / 2
        val l = ox + cw * (1 - GW) / 2; val r = ox + cw * (1 + GW) / 2
        val tp = oy + chh * (1 - GH) / 2; val bt = oy + chh * (1 + GH) / 2
        c.drawRect(l, tp, r, bt, line)
        val colW = (r - l) / 4
        for (i in 1..3) c.drawLine(l + colW * i, tp + (bt - tp) * BLUE_FROM, l + colW * i, bt, line)
        for (i in 0..3) c.drawText(METHODS[i], r - colW * (i + 0.5f), bt - 10f, txt)
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var db: Db
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var counter: TextView
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 90)
    private var lastKey = ""
    private var streak = 0
    private var doneKey = ""
    private var paused = false
    private var lastParsed: Parsed? = null
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private var cashier: String
        get() = prefs.getString("cashier", "") ?: ""
        set(v) { prefs.edit().putString("cashier", v).apply() }

    private val askCam = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else status.text = "الكاميرا غير مسموحة"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24)
            text = "وجّه الوصل داخل الإطار الأخضر"
        }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
        val frame = FrameLayout(this)
        frame.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        frame.addView(GuideView(this), FrameLayout.LayoutParams(-1, -1))
        counter = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(8, 8, 8, 8) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        for (b in listOf(
            btn("القائمة") { showList() },
            btn("تصدير Excel") { export() },
            btn("إدخال يدوي") { manualDialog() },
            btn("الكاشير") { cashierDialog() }
        )) bar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(status, LinearLayout.LayoutParams(-1, -2))
        col.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(counter, LinearLayout.LayoutParams(-1, -2))
        col.addView(bar, LinearLayout.LayoutParams(-1, -2))
        setContentView(col)
        refreshCounter()
        if (cashier.isEmpty()) cashierDialog()
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else askCam.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val cp = fut.get()
            val preview = Preview.Builder().setTargetResolution(Size(1080, 1440)).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setTargetResolution(Size(1080, 1440))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(Executors.newSingleThreadExecutor(), SlipAnalyzer { runOnUiThread { onParsed(it) } })
            cp.unbindAll()
            cp.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onParsed(p: Parsed) {
        lastParsed = p
        if (paused) return
        if (p.serial == null || p.amount == null) { streak = 0; status.text = "وجّه الوصل داخل الإطار الأخضر"; return }
        if (p.date == null) { status.text = "رقم ${p.serial}: لم أقرأ التاريخ"; return }
        if (p.method < 0) { status.text = "رقم ${p.serial}: لم أجد الختم الأزرق (استخدم الإدخال اليدوي)"; return }
        val key = "${p.serial}|${p.amount}|${p.date}|${p.method}"
        if (key == doneKey) return
        if (key == lastKey) streak++ else { lastKey = key; streak = 1 }
        if (streak < 2) return
        streak = 0
        doneKey = key
        val ok = db.insert(Slip(0, p.serial, p.amount, p.method, p.date, p.time ?: "", cashier))
        if (ok) {
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            status.text = "✔ ${p.serial} | ${fmt(p.amount)} | ${METHODS[p.method]}"
        } else {
            tone.startTone(ToneGenerator.TONE_SUP_ERROR, 300)
            status.text = "⚠ مكرر: رقم ${p.serial} مسجل مسبقاً"
        }
        refreshCounter()
    }

    private fun fmt(d: Double) = String.format(Locale.US, "%.2f", d)

    private fun refreshCounter() {
        counter.text = "الكاشير: ${cashier.ifEmpty { "-" }}   |   عدد الوصولات: ${db.count()}"
    }

    private fun cashierDialog() {
        val et = EditText(this).apply { setText(cashier); hint = "اسم الكاشير" }
        AlertDialog.Builder(this).setTitle("اسم الكاشير لهذه الدفعة").setView(et)
            .setPositiveButton("حفظ") { _, _ -> cashier = et.text.toString().trim(); refreshCounter() }
            .show()
    }

    private fun manualDialog() {
        val p = lastParsed
        paused = true
        val lay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val serial = EditText(this).apply { hint = "رقم الوصل"; setText(p?.serial ?: "") }
        val amount = EditText(this).apply { hint = "المبلغ"; setText(p?.amount?.let { fmt(it) } ?: "") }
        val date = EditText(this).apply { hint = "التاريخ 19/10/2026"; setText(p?.date ?: "") }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, METHODS)
            if ((p?.method ?: -1) >= 0) setSelection(p!!.method)
        }
        for (v in listOf(serial, amount, date, sp)) lay.addView(v)
        AlertDialog.Builder(this).setTitle("إدخال يدوي").setView(lay)
            .setPositiveButton("حفظ") { _, _ ->
                val a = amount.text.toString().replace(',', '.').toDoubleOrNull()
                val s = Digits.norm(serial.text.toString()).trim()
                if (s.isEmpty() || a == null) { Toast.makeText(this, "الرقم والمبلغ مطلوبان", Toast.LENGTH_SHORT).show() }
                else {
                    val ok = db.insert(Slip(0, s, a, sp.selectedItemPosition, Digits.norm(date.text.toString()).trim(), p?.time ?: "", cashier))
                    Toast.makeText(this, if (ok) "تم الحفظ" else "مكرر", Toast.LENGTH_SHORT).show()
                    refreshCounter()
                }
            }
            .setNegativeButton("إلغاء", null)
            .setOnDismissListener { paused = false }
            .show()
    }

    private fun showList() {
        val all = db.all()
        val sums = DoubleArray(4); val cnt = IntArray(4)
        for (s in all) { sums[s.method] += s.amount; cnt[s.method]++ }
        val summary = METHODS.indices.joinToString("\n") { "${METHODS[it]}: ${cnt[it]} وصل = ${fmt(sums[it])}" } +
            "\nالمجموع: ${all.size} وصل = ${fmt(sums.sum())}"
        val items = all.take(300).map { "${it.serial} | ${fmt(it.amount)} | ${METHODS[it.method]} | ${it.date}" }.toTypedArray()
        paused = true
        AlertDialog.Builder(this).setTitle(summary)
            .setItems(items) { _, i ->
                val s = all[i]
                AlertDialog.Builder(this).setMessage("حذف الوصل ${s.serial}؟")
                    .setPositiveButton("حذف") { _, _ -> db.delete(s.id); refreshCounter() }
                    .setNegativeButton("لا", null).show()
            }
            .setNegativeButton("إغلاق", null)
            .setOnDismissListener { paused = false }
            .show()
    }

    private fun export() {
        val all = db.all()
        if (all.isEmpty()) { Toast.makeText(this, "لا توجد وصولات", Toast.LENGTH_SHORT).show(); return }
        try {
            val name = exportXlsx(this, all)
            Toast.makeText(this, "تم الحفظ في مجلد Downloads: $name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل التصدير: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
